# LAB02 Solution Key — Cloud Security Posture Review Checklist

## Expected outcomes

Students should verify:

- Defender for Cloud access.
- Environment settings visibility.
- Secure Score / recommendations visibility.
- Regulatory compliance dashboard availability.
- At least three findings documented with evidence.
- Clear prioritization of critical/high recommendations.

## Common issues

| Issue | Likely cause | Resolution |
|---|---|---|
| Recommendations not visible | No Reader/Contributor/Owner scope | Confirm RBAC assignment |
| Plan toggles disabled | Insufficient permission | Use Security Admin/Contributor/Owner as approved |
| Score differs from screenshots | Portal UI/data refresh changes | Explain portal variance and use current live evidence |
