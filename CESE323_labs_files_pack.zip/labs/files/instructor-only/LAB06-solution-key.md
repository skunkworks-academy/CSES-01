# LAB06 Solution Key — 30-Day Remediation Roadmap

## Expected outcomes

The roadmap should include:

- Early governance and scope confirmation.
- Critical exposure fixes in week 1.
- Identity hardening in week 2.
- Workload protection validation in week 3.
- Attack path reduction and executive reporting by day 30.

## Instructor note

The roadmap should balance quick wins and realistic change control. Penalize unrealistic remediation plans that assume production-wide change without approval.
