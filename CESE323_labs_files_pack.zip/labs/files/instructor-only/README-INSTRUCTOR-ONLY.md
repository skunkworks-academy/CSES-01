# Instructor-Only Files

These files are not for student distribution.

## Handling rules

- Do not publish this folder to GitHub Pages.
- Do not upload to a public LMS section.
- Do not include in student ZIP packages.
- Do not share solution keys before lab completion.
- Redact tenant-specific data before using screenshots in instructor materials.

## Included files

| File | Purpose |
|---|---|
| `LAB01-solution-key.md` | Suggested solution notes for Security Priority Map |
| `LAB02-solution-key.md` | Suggested solution notes for CSPM review |
| `LAB03-solution-key.md` | Suggested solution notes for workload protection selection |
| `LAB04-solution-key.md` | Suggested solution notes for AI security risk review |
| `LAB05-solution-key.md` | Suggested solution notes for attack path planning |
| `LAB06-solution-key.md` | Suggested solution notes for 30-day roadmap |
| `cost-safety-briefing.md` | Instructor warning script for cost and live environments |
| `live-environment-change-control-template.md` | Controlled live-environment approval form |
