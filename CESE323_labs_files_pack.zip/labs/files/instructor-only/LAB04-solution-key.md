# LAB04 Solution Key — AI Security Risk Review

## Expected outcomes

Students should identify AI-specific risks:

- Prompt injection.
- Data leakage.
- Unsafe output.
- Overprivileged managed identity.
- Missing monitoring.
- Missing AI workload protection coverage.
- Lack of prompt/data usage policy.

## Strong answer indicators

A strong answer separates management-plane risk, data-plane risk, model/prompt risk, and monitoring/response risk.
