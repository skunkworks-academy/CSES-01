# LAB03 Solution Key — Workload Protection Selection Matrix

## Expected outcomes

Students should select workload protection plans based on risk, workload type, business criticality, and cost approval.

## Acceptable selections

| Workload | Preferred plan |
|---|---|
| Storage account | Defender for Storage |
| AKS / container workload | Defender for Containers |
| App Service | Defender for App Service |
| Azure AI / Foundry | Defender for AI Services / AI workload protection |

## Instructor note

Students must not enable every paid plan by default. The learning objective is selection discipline, not maximum activation.
