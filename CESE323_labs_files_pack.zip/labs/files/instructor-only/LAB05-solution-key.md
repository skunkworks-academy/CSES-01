# LAB05 Solution Key — Attack Path and Remediation Planning

## Expected outcomes

Students should decompose the path into:

1. Entry point.
2. Intermediate asset or identity.
3. Permission/control weakness.
4. Critical asset.
5. Choke point.
6. Remediation plan.
7. Validation method.

## Scoring guidance

Award strongest marks for students who identify a choke point that breaks more than one risk chain.
