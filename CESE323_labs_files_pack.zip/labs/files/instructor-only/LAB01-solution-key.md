# LAB01 Solution Key — Security Priority Map

## Expected outcomes

Students should produce:

- A clear mapping from business priorities to technical controls.
- At least three prioritized risk vectors.
- At least one identity risk, one workload risk, and one operational/governance risk.
- A justification for why their highest-priority risk should be remediated first.

## Instructor hints

Good answers should avoid purely tool-based thinking. Push students to connect findings to business outcomes such as data confidentiality, operational availability, regulatory exposure, and incident response readiness.
