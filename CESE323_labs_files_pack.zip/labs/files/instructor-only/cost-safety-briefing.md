# Instructor Cost and Safety Briefing

Read or summarize this before any live Defender for Cloud activity.

## Key warnings

- Some Defender for Cloud workload protection plans are paid.
- Do not enable paid plans without approval.
- Do not enable plans across production subscriptions unless explicitly approved.
- Use sandbox subscriptions wherever possible.
- Defender for Storage malware scanning may generate charges depending current plan behavior and configuration.
- Lab resources must be cleaned up after the course.
- Students must not upload sensitive data or enter confidential prompts into AI systems.

## Live environment rule

If the customer wants live review, treat it as a controlled operational review, not a student experimentation environment.
