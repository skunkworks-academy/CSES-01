# Instructor Live Environment Change Control Template

**Customer / tenant:**  
**Subscription(s):**  
**Resource group(s):**  
**Approved plan(s):**  
**Approved by:**  
**Approval date:**  
**Change window:**  

## Approved actions

| Action | Approved? | Notes |
|---|---|---|
| View Defender posture |  |  |
| Export recommendations |  |  |
| Enable Defender plan |  |  |
| Assign policy |  |  |
| Remediate resource setting |  |  |
| Create lab resource |  |  |
| Delete lab resource |  |  |

## Rollback plan

| Action | Rollback owner | Completion evidence |
|---|---|---|
|  |  |  |

## Data handling

- [ ] No sensitive customer data used in examples.
- [ ] Screenshots redacted.
- [ ] Named accounts used.
- [ ] Audit trail retained.
