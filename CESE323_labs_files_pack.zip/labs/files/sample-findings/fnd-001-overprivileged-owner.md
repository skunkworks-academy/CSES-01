# FND-001 — Overprivileged Owner Assignment

| Field | Value |
|---|---|
| Severity | High |
| Risk type | Identity / RBAC |
| Affected asset | Subscription or resource group |
| Evidence source | Azure RBAC role assignments / Defender recommendation |
| Business impact | Excessive permissions increase blast radius if the identity is compromised. |

## Observation

A user, group, service principal, or managed identity has `Owner` at broad scope where `Contributor`, `Security Admin`, or a narrower custom role would be sufficient.

## Recommended remediation

1. Confirm business justification for broad Owner access.
2. Replace standing access with least-privilege RBAC.
3. Use privileged access workflow / just-in-time elevation where available.
4. Review service principals and managed identities for unused broad permissions.
5. Record change approval before removing access in customer environments.

## Validation

- Role assignment removed or reduced.
- Access still supports the required lab/business task.
- No emergency or break-glass account was removed.
