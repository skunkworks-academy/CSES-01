# FND-004 — AI Workload Has No Guardrails or Monitoring

| Field | Value |
|---|---|
| Severity | High |
| Risk type | AI security / data leakage / unsafe behavior |
| Affected asset | Azure AI service / Foundry project / model deployment |
| Evidence source | AI service configuration, Defender for Cloud AI posture, policy review |
| Business impact | AI workloads may leak sensitive data, process unsafe prompts, or operate without audit visibility. |

## Observation

The AI workload has no clear policy for prompt data handling, identity scope, monitoring, or unsafe output review.

## Recommended remediation

1. Define prompt and data handling rules.
2. Verify managed identities and RBAC assignments.
3. Enable Defender for AI Services where approved and available.
4. Review the Data and AI security dashboard where included.
5. Implement logging and incident review workflow.

## Validation

- AI plan status confirmed.
- Monitoring evidence captured.
- Sensitive prompt/data rules documented.
