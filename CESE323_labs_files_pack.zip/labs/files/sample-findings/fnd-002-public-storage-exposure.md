# FND-002 — Public Storage Exposure

| Field | Value |
|---|---|
| Severity | High |
| Risk type | Data exposure |
| Affected asset | Azure Storage account / blob container |
| Evidence source | Defender for Cloud recommendation / Storage configuration |
| Business impact | Publicly accessible data may lead to confidentiality breach and compliance impact. |

## Observation

A storage account or container is configured in a way that may allow unintended public access.

## Recommended remediation

1. Disable anonymous blob access unless explicitly required.
2. Restrict network access with private endpoints or approved networks.
3. Enable Defender for Storage only if approved for the lab scope and cost model.
4. Review data classification and remove sensitive test data.
5. Validate access after remediation.

## Validation

- Anonymous access disabled or intentionally documented.
- Network access scope reduced.
- Defender recommendation status improves after platform refresh.
