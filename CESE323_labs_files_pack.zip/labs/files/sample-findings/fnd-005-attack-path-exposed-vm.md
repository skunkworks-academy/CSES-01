# FND-005 — Attack Path from Exposed Asset to Critical Resource

| Field | Value |
|---|---|
| Severity | Critical / High |
| Risk type | Exposure management / lateral movement |
| Affected asset | Internet-facing VM, app, identity, or data resource |
| Evidence source | Defender for Cloud attack path / exposure view / instructor scenario |
| Business impact | An attacker may chain exposure, weak identity, and workload misconfiguration to reach critical assets. |

## Observation

A chain of weaknesses creates an attack path from an exposed asset to a high-value target.

## Recommended remediation

1. Identify the entry point and all intermediate assets.
2. Select remediation choke points.
3. Remove public exposure where possible.
4. Reduce excessive permissions.
5. Enable relevant Defender plans and logging.
6. Validate that attack path risk is reduced after platform refresh.

## Validation

- Attack path removed or severity reduced.
- Choke point control implemented.
- Residual risk documented.
