# FND-003 — Defender Workload Plan Not Enabled

| Field | Value |
|---|---|
| Severity | Medium / High |
| Risk type | Workload protection coverage |
| Affected asset | Subscription or workload type |
| Evidence source | Defender for Cloud Environment settings |
| Business impact | Missing workload plan reduces detection, alerting, and posture coverage. |

## Observation

The relevant Defender workload protection plan is disabled for a workload selected in the lab scope.

## Recommended remediation

1. Confirm the selected workload and plan requirement.
2. Confirm cost approval.
3. Enable the plan only at the approved scope.
4. Validate coverage using Environment settings and relevant workbook/dashboard.
5. Disable lab-only plans after the course if they are not required long term.

## Validation

- Defender plan status shows enabled.
- Workload appears in coverage view.
- Alerts/recommendations are visible where applicable.
