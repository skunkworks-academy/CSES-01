# Lab Link Index

Use this file as the canonical internal index for `/labs/files`.

## Core student templates

- [Lab 01 Security Priority Map Template](templates/01-security-priority-map-template.md)
- [Lab 02 Cloud Security Posture Review Checklist](templates/02-cloud-security-posture-review-checklist.md)
- [Lab 03 Workload Protection Selection Matrix CSV](templates/03-workload-protection-selection-matrix.csv)
- [Lab 03 Workload Protection Selection Matrix Markdown](templates/03-workload-protection-selection-matrix.md)
- [Lab 04 AI Security Risk Review Template](templates/04-ai-security-risk-review-template.md)
- [Lab 05 Attack Path and Remediation Planning Template](templates/05-attack-path-remediation-planning-template.md)
- [Lab 06 30-Day Remediation Roadmap Template](templates/06-30-day-remediation-roadmap-template.md)

## Shared templates

- [Finding Register Template CSV](templates/finding-register-template.csv)
- [Remediation Plan Template CSV](templates/remediation-plan-template.csv)
- [Executive Summary Template](templates/executive-summary-template.md)
- [Change Control Template](templates/change-control-template.md)

## Diagrams

- [Defender for Cloud Lab Flow](diagrams/defender-cloud-lab-flow.mmd)
- [CSPM Posture Review Flow](diagrams/cspm-posture-review-flow.mmd)
- [Workload Protection Selection Map](diagrams/workload-protection-selection-map.mmd)
- [AI Security Risk Flow](diagrams/ai-security-risk-flow.mmd)
- [Attack Path Remediation Flow](diagrams/attack-path-remediation-flow.mmd)
- [SVG Diagram Index](diagrams/README.md)

## Sample findings

- [Overprivileged Owner Assignment](sample-findings/fnd-001-overprivileged-owner.md)
- [Public Storage Exposure](sample-findings/fnd-002-public-storage-exposure.md)
- [Defender Plan Not Enabled](sample-findings/fnd-003-defender-plan-not-enabled.md)
- [AI Workload No Guardrails](sample-findings/fnd-004-ai-workload-no-guardrails.md)
- [Attack Path Exposed VM](sample-findings/fnd-005-attack-path-exposed-vm.md)

## Remediation examples

- [Enable Defender Plan](remediation-examples/rem-001-enable-defender-plan.md)
- [Reduce RBAC Privilege](remediation-examples/rem-002-reduce-rbac-privilege.md)
- [Secure Storage](remediation-examples/rem-003-secure-storage.md)
- [Enable Defender for AI Services](remediation-examples/rem-004-enable-defender-for-ai-services.md)
- [Attack Path Prioritization](remediation-examples/rem-005-attack-path-prioritization.md)
- [30-Day Roadmap Example](remediation-examples/30-day-roadmap-example.md)

## Screenshots and validation

- [Screenshot Capture Guide](screenshots/README.md)
- [Screenshot Validation Register](validation/screenshot-validation-register.csv)
- [Lab Step Validation Register](validation/lab-step-validation-register.csv)
- [Portal Version Log](validation/portal-version-log.md)
- [Internal Link Validation Report](validation/internal-link-validation-report.md)

## Instructor-only files

- [Instructor-Only README](instructor-only/README-INSTRUCTOR-ONLY.md)
- [Lab 01 Solution Key](instructor-only/LAB01-solution-key.md)
- [Lab 02 Solution Key](instructor-only/LAB02-solution-key.md)
- [Lab 03 Solution Key](instructor-only/LAB03-solution-key.md)
- [Lab 04 Solution Key](instructor-only/LAB04-solution-key.md)
- [Lab 05 Solution Key](instructor-only/LAB05-solution-key.md)
- [Lab 06 Solution Key](instructor-only/LAB06-solution-key.md)
