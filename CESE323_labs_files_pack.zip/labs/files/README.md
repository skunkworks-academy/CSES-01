# CESE323 Lab Files

**Course:** CESE323 ERC1.0 — Cloud Security Envisioning & Strategy  
**Folder:** `/labs/files`  
**Generated:** 2026-05-25

This folder contains the repo-ready lab support files for the CESE323 workshop. It is designed to support six core labs:

| Lab | Focus | Primary file assets |
|---|---|---|
| Lab 01 | Security Priority Map | `templates/01-security-priority-map-template.md`, `diagrams/cspm-posture-review-flow.mmd` |
| Lab 02 | Cloud Security Posture Review Checklist | `templates/02-cloud-security-posture-review-checklist.md`, `sample-findings/fnd-003-defender-plan-not-enabled.md` |
| Lab 03 | Workload Protection Selection Matrix | `templates/03-workload-protection-selection-matrix.csv`, `diagrams/workload-protection-selection-map.mmd` |
| Lab 04 | AI Security Risk Review | `templates/04-ai-security-risk-review-template.md`, `diagrams/ai-security-risk-flow.mmd` |
| Lab 05 | Attack Path and Remediation Planning | `templates/05-attack-path-remediation-planning-template.md`, `diagrams/attack-path-remediation-flow.mmd` |
| Lab 06 | 30-Day Remediation Roadmap | `templates/06-30-day-remediation-roadmap-template.md`, `remediation-examples/30-day-roadmap-example.md` |

## Folder structure

```text
/labs/files
├── README.md
├── manifest.json
├── lab-link-index.md
├── templates/
├── diagrams/
├── screenshots/
├── sample-findings/
├── remediation-examples/
├── instructor-only/
├── validation/
├── scripts/
└── sample-data/
```

## Safety model

These files are built for a training environment and should not require production changes. Where labs touch Microsoft Defender for Cloud, Microsoft Defender XDR, Microsoft Entra, Azure AI, Microsoft Foundry, AKS, App Service, or Storage, use a dedicated lab subscription or isolated resource groups wherever possible.

Do **not** upload customer data, PII, confidential prompts, HR/legal data, financial data, production secrets, or proprietary source code into any lab workload, storage account, AI service, or screenshot.

## Official Microsoft reference links used by the lab pack

| Area | Link |
|---|---|
| Microsoft Defender for Cloud overview | https://learn.microsoft.com/azure/defender-for-cloud/defender-for-cloud-introduction |
| Connect Azure subscriptions to Defender for Cloud | https://learn.microsoft.com/azure/defender-for-cloud/connect-azure-subscription |
| Defender for Cloud roles and permissions | https://learn.microsoft.com/azure/defender-for-cloud/permissions |
| Review Defender for Cloud security recommendations | https://learn.microsoft.com/azure/defender-for-cloud/review-security-recommendations |
| Secure Score in Defender for Cloud | https://learn.microsoft.com/azure/defender-for-cloud/secure-score-security-controls |
| Enable threat protection for AI services | https://learn.microsoft.com/azure/defender-for-cloud/ai-onboarding |
| Learn module: Enable Defender for AI Services workload protection | https://learn.microsoft.com/training/modules/implement-defender-cloud-ai-services/ |

## Validation status

- Internal package links: validated in `validation/internal-link-validation-report.md`
- Lab-step validation register: created in `validation/lab-step-validation-register.csv`
- Screenshot validation register: created in `validation/screenshot-validation-register.csv`
- Portal validation notes: created in `validation/portal-version-log.md`

## Instructor-only content

Instructor solution files are stored in `instructor-only/`. Keep this folder out of student-facing downloads, LMS student areas, public repos, and GitHub Pages publishing unless protected by repository permissions.
