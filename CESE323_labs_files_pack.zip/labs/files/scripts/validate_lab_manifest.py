#!/usr/bin/env python3
"""Validate CESE323 /labs/files manifest references."""

from pathlib import Path
import json
import sys

root = Path(__file__).resolve().parents[1]
manifest_path = root / "manifest.json"

if not manifest_path.exists():
    print("ERROR: manifest.json not found")
    sys.exit(1)

manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
missing = []

for lab in manifest.get("labs", []):
    for key in ("student_template", "solution"):
        rel = lab.get(key)
        if rel and not (root / rel).exists():
            missing.append((lab.get("id"), key, rel))

if missing:
    print("Missing manifest references:")
    for lab_id, key, rel in missing:
        print(f"- {lab_id}: {key} -> {rel}")
    sys.exit(1)

print("Manifest references validated successfully.")
