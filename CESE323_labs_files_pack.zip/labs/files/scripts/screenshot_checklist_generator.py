#!/usr/bin/env python3
"""Print screenshot validation checklist from CSV."""

from pathlib import Path
import csv

root = Path(__file__).resolve().parents[1]
csv_path = root / "validation" / "screenshot-validation-register.csv"

with csv_path.open(encoding="utf-8", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        print(f"[ ] {row['Screenshot ID']} — {row['Lab']} — {row['Navigation path']} — {row['Current portal validation status']}")
