<#
.SYNOPSIS
Validates local Markdown links under /labs/files.

.DESCRIPTION
Run from repository root or from the /labs/files folder.
External HTTP links are listed but not fetched by default.
#>

param(
    [string]$RootPath = "."
)

$ErrorActionPreference = "Stop"
$root = Resolve-Path $RootPath
$mdFiles = Get-ChildItem -Path $root -Filter *.md -Recurse
$missing = @()
$external = @()

foreach ($file in $mdFiles) {
    $content = Get-Content $file.FullName -Raw
    $matches = [regex]::Matches($content, '\[[^\]]+\]\(([^)]+)\)')
    foreach ($match in $matches) {
        $link = $match.Groups[1].Value
        if ($link -match '^(http|https)://') {
            $external += [pscustomobject]@{ File = $file.FullName; Link = $link }
            continue
        }
        if ($link -match '^#') { continue }
        $clean = ($link -split '#')[0]
        if ([string]::IsNullOrWhiteSpace($clean)) { continue }
        $target = Join-Path $file.DirectoryName $clean
        if (-not (Test-Path $target)) {
            $missing += [pscustomobject]@{ File = $file.FullName; MissingLink = $link; ResolvedTarget = $target }
        }
    }
}

"External links listed:"
$external | Format-Table -AutoSize

if ($missing.Count -gt 0) {
    "Missing local links:"
    $missing | Format-Table -AutoSize
    exit 1
}

"All local Markdown links resolved successfully."
