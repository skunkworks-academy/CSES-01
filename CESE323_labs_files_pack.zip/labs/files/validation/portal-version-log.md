# Portal Version Log

**Generated:** 2026-05-25

This log records what must be checked when screenshots and lab steps are finalized against the live Microsoft portal experience.

## Current validation notes

| Area | Current validation guidance |
|---|---|
| Defender for Cloud activation | Use Azure portal > Microsoft Defender for Cloud > Environment settings. |
| Defender recommendations | Use Defender for Cloud > Recommendations and verify filters, owner/status fields, and affected resources. |
| Secure Score | Confirm whether using Microsoft Defender portal risk-based Cloud Secure Score or classic score in Azure portal. |
| Defender for AI Services | Verify availability of AI services plan under Defender plans and confirm required permissions before enabling. |
| Microsoft Defender portal | Validate alert/incident screens only with demo or redacted data. |

## Screenshot validation rule

Screenshots must be replaced if any of the following changed:

- Portal navigation path changed.
- Button or menu names changed.
- Page no longer exists in the same portal.
- Screenshot shows stale preview UI.
- Screenshot exposes real tenant, user, subscription, or customer data.
- Screenshot does not match the live lab flow.

## External official references

- https://learn.microsoft.com/azure/defender-for-cloud/connect-azure-subscription
- https://learn.microsoft.com/azure/defender-for-cloud/review-security-recommendations
- https://learn.microsoft.com/azure/defender-for-cloud/secure-score-security-controls
- https://learn.microsoft.com/azure/defender-for-cloud/permissions
- https://learn.microsoft.com/azure/defender-for-cloud/ai-onboarding
