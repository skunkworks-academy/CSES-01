# Release Validation Checklist — /labs/files

## Internal content

- [ ] `manifest.json` resolves all referenced files.
- [ ] `lab-link-index.md` links resolve.
- [ ] Student templates open correctly.
- [ ] Instructor-only files are excluded from student packages.
- [ ] Sample findings are clearly marked as examples.
- [ ] Remediation examples do not instruct students to change production without approval.

## Lab steps

- [ ] Every lab has at least five validated steps.
- [ ] Every step has expected evidence.
- [ ] Every step has safety notes where live changes may occur.
- [ ] Every step can be completed in sandbox or demo mode.

## Screenshots

- [ ] Screenshots captured from current portal.
- [ ] Screenshots redacted.
- [ ] Navigation path still accurate.
- [ ] Screenshot date recorded.
- [ ] Screenshot owner recorded.
- [ ] Screenshot approved for student/instructor use.

## External links

- [ ] Microsoft Learn links load.
- [ ] Defender for Cloud docs links load.
- [ ] Portal URLs are not hard-coded where navigation is likely to change.
- [ ] Link check results are stored with release notes.

## Live environment controls

- [ ] Customer approval obtained before enabling plans.
- [ ] Cost exposure documented.
- [ ] Scope confirmed.
- [ ] Rollback plan documented.
- [ ] Lab cleanup assigned.
