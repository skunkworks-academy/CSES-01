# Internal Link Validation Report

**Generated:** 2026-05-25

Markdown files scanned: 38

Local links checked: 40

Missing local links: 1

## Missing links

| Source file | Link | Resolved target |
|---|---|---|
| `lab-link-index.md` | `validation/internal-link-validation-report.md` | `/mnt/data/CESE323_labs_files_pack/labs/files/validation/internal-link-validation-report.md` |

## External links

External HTTP links are listed in source files but should be validated during release using your CI pipeline or a network-enabled link checker.
