# REM-005 — Prioritize Attack Path Remediation

## Use case

An attack path or exposure chain shows how a threat actor could traverse from an exposed asset to a critical asset.

## Procedure

1. Record the entry point.
2. Record the identity or permission chain.
3. Record the critical asset at risk.
4. Identify at least two choke points.
5. Prioritize fixes by risk reduction and implementation effort.
6. Create remediation actions.
7. Revalidate after platform refresh.

## Example choke points

| Choke point | Control |
|---|---|
| Public management port | Restrict network access / use Bastion / VPN |
| Broad Owner role | Reduce RBAC scope |
| Missing Defender plan | Enable approved workload protection |
| Sensitive storage exposure | Restrict access and classify data |
