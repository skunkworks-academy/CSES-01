# REM-003 — Secure Storage Exposure

## Use case

A storage account or blob container is exposed or lacks appropriate workload protection.

## Procedure

1. Review anonymous access settings.
2. Review networking/firewall/private endpoint configuration.
3. Review data sensitivity of test files.
4. Enable Defender for Storage only if approved.
5. Capture before/after evidence.
6. Validate access behavior.

## Lab-safe test data

Use synthetic files only. Do not upload customer, financial, legal, HR, credential, or proprietary data.
