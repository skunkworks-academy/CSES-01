# REM-001 — Enable an Approved Defender Workload Plan

## Use case

A selected workload is in scope for the lab, but the related Defender workload protection plan is disabled.

## Preconditions

- Written approval for paid plan activation.
- Confirmed subscription/resource scope.
- Required permissions assigned.
- Rollback plan documented.

## Procedure

1. Sign in to the Azure portal.
2. Search for and open **Microsoft Defender for Cloud**.
3. Open **Environment settings**.
4. Select the approved subscription.
5. Open the **Defender plans** page.
6. Enable only the approved plan.
7. Save changes.
8. Validate plan status and coverage.

## Rollback

Disable the lab-only plan after training if it is not required for ongoing security operations.

## Evidence

- Before/after screenshot of Defender plan status.
- Approval record.
- Lab validation notes.
