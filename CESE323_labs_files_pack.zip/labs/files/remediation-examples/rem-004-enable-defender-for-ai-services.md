# REM-004 — Enable Defender for AI Services

## Use case

AI workload protection is selected for the lab and the subscription contains approved Azure AI / Foundry resources.

## Preconditions

- Azure subscription available.
- Defender for Cloud enabled.
- Owner or Contributor permissions available to enable plan.
- AI resource exists or is created in a sandbox.
- Cost approval completed.
- No confidential prompt/data testing.

## Procedure

1. Sign in to the Azure portal.
2. Open **Microsoft Defender for Cloud**.
3. Go to **Environment settings**.
4. Select the target subscription.
5. On **Defender plans**, turn **AI services** on where available.
6. Review plan configuration.
7. Review the Data and AI security dashboard where available.
8. Capture evidence and update the findings register.

## Validation

- AI Services plan shows enabled.
- AI posture/alerts/dashboard evidence captured.
- Prompt/data safety rules documented.
