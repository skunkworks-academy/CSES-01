# REM-002 — Reduce Broad RBAC Privilege

## Use case

A user, group, service principal, or managed identity has broad access at subscription or management group scope.

## Procedure

1. Identify the role assignment and scope.
2. Confirm business owner and required actions.
3. Select least-privilege replacement role.
4. Apply change during approved window.
5. Validate access with the affected user/service.
6. Record evidence.

## Controls

- Use named accounts.
- Avoid shared admin accounts.
- Preserve break-glass access.
- Do not remove unknown service principals without owner validation.
