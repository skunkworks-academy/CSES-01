# Lab 02 Template — Cloud Security Posture Review Checklist

**Student name:**  
**Subscription/resource group:**  
**Review mode:** View-only / Guided remediation / Live customer review  

## 1. Access and environment checks

| Check | Expected result | Evidence | Status |
|---|---|---|---|
| Azure portal loads | Student can access target tenant and subscription | Screenshot / notes | Not started |
| Defender for Cloud visible | Defender for Cloud menu is available | Screenshot / notes | Not started |
| Environment settings visible | Student can view subscription plan settings | Screenshot / notes | Not started |
| Secure Score visible | Secure Score page loads | Screenshot / notes | Not started |
| Recommendations visible | Recommendations page lists assessed resources | Screenshot / notes | Not started |
| Regulatory compliance visible | Compliance dashboard loads | Screenshot / notes | Not started |

## 2. CSPM review checklist

| Area | Review question | Evidence required | Risk rating | Finding ID |
|---|---|---|---|---|
| Secure Score | What are the top score-impacting controls? | Secure Score screenshot |  |  |
| Recommendations | Which critical/high recommendations exist? | Recommendation details |  |  |
| Resource coverage | Are all expected subscriptions/resources visible? | Asset inventory |  |  |
| Identity exposure | Are privileged identities over-scoped? | RBAC export / screenshot |  |  |
| Regulatory compliance | Which controls are failing? | Compliance control details |  |  |
| Workload protection | Which Defender plans are enabled/disabled? | Environment settings screenshot |  |  |
| Attack paths | Are attack paths detected? | Attack path screenshot |  |  |

## 3. Findings register

| Finding ID | Finding title | Affected asset | Severity | Evidence | Recommended action |
|---|---|---|---|---|---|
| FND-001 |  |  |  |  |  |
| FND-002 |  |  |  |  |  |
| FND-003 |  |  |  |  |  |

## 4. Lab completion criteria

- [ ] Evidence captured for each reviewed area.
- [ ] At least three findings documented.
- [ ] At least one identity-related risk identified.
- [ ] At least one workload protection gap identified.
- [ ] At least one 30-day remediation action proposed.
