# Lab 01 Template — Security Priority Map

**Student name:**  
**Tenant/subscription:**  
**Date:**  
**Scenario:** Training / sandbox / customer live review  

## 1. Business security priorities

| Priority | Business driver | Security concern | Stakeholder | Notes |
|---|---|---|---|---|
| P1 | Example: protect customer data | Example: public exposure | CISO / IT lead |  |
| P2 |  |  |  |  |
| P3 |  |  |  |  |

## 2. Risk vectors

| Risk vector | Example indicator | Likelihood | Impact | Priority |
|---|---|---:|---:|---:|
| Misconfiguration | Public endpoint, weak network rule, missing diagnostics |  |  |  |
| Over-privileged identity | Owner at subscription scope, unused admin roles |  |  |  |
| Workload exposure | Unprotected storage, app service, container, or AI resource |  |  |  |
| Attack path | Privilege chain from exposed asset to sensitive resource |  |  |  |

## 3. Security priority map

| Security objective | Current state | Target state | Microsoft control area | Evidence required |
|---|---|---|---|---|
| Improve posture visibility |  |  | Defender for Cloud CSPM | Secure Score / recommendations screenshot |
| Reduce identity blast radius |  |  | Microsoft Entra / RBAC | Role assignment export |
| Protect selected workloads |  |  | Defender plans | Environment settings screenshot |
| Reduce attack paths |  |  | Attack path analysis / recommendations | Attack path evidence |
| Prepare remediation roadmap |  |  | Governance / tracking | 30-day roadmap |

## 4. Priority scoring

Use 1–5 scoring.

| Finding / risk | Impact | Likelihood | Exposure | Ease of remediation | Priority score | Rank |
|---|---:|---:|---:|---:|---:|---:|
|  |  |  |  |  |  |  |

**Suggested formula:** `(Impact + Likelihood + Exposure) - Ease of remediation`

## 5. Student reflection

1. Which risk should be remediated first, and why?  
2. Which risk requires stakeholder approval before action?  
3. Which risk can be mitigated within 30 days?  
4. Which risk needs architecture redesign or budget approval?
