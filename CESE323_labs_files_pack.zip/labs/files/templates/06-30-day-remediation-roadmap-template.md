# Lab 06 Template — 30-Day Remediation Roadmap

**Environment:**  
**Prepared by:**  
**Date:**  

## 1. Remediation themes

| Theme | Objective | Key findings addressed |
|---|---|---|
| Identity hardening | Reduce excessive permissions and blast radius |  |
| Posture management | Improve recommendations, Secure Score, compliance |  |
| Workload protection | Enable appropriate Defender protections |  |
| AI security | Reduce AI data leakage and identity risks |  |
| Operational readiness | Establish governance, ownership, and repeatable review |  |

## 2. 30-day roadmap

| Timeline | Action | Owner | Dependencies | Evidence of completion |
|---|---|---|---|---|
| Day 0–3 | Confirm subscription scope, budget approval, and change controls |  |  |  |
| Day 4–7 | Review top critical/high recommendations and assign owners |  |  |  |
| Day 8–14 | Remediate identity and public exposure risks |  |  |  |
| Day 15–21 | Enable/validate selected Defender workload plans |  |  |  |
| Day 22–27 | Validate attack path reduction and dashboard visibility |  |  |  |
| Day 28–30 | Produce executive report and next-phase backlog |  |  |  |

## 3. Success metrics

| Metric | Baseline | Target | Actual |
|---|---:|---:|---:|
| Critical recommendations |  |  |  |
| High recommendations |  |  |  |
| Unassigned recommendations |  |  |  |
| Publicly exposed critical assets |  |  |  |
| Overprivileged admin assignments |  |  |  |
| Defender plan coverage |  |  |  |

## 4. Risks and approvals

| Risk / blocker | Impact | Decision required | Owner |
|---|---|---|---|
| Cost approval for paid plans |  |  |  |
| Production change window |  |  |  |
| Data classification gaps |  |  |  |
| Missing permissions |  |  |  |
