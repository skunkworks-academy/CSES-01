# Change Control Template — Defender for Cloud Lab / Live Review

**Change title:**  
**Environment:** Lab / customer live / production / non-production  
**Subscription/resource group:**  
**Requested by:**  
**Approved by:**  
**Planned window:**  

## Scope

| In scope | Out of scope |
|---|---|
|  |  |

## Change actions

| Step | Action | Owner | Rollback |
|---:|---|---|---|
| 1 |  |  |  |
| 2 |  |  |  |

## Risk controls

- [ ] Written approval obtained.
- [ ] Subscription scope confirmed.
- [ ] Budget/cost exposure approved.
- [ ] Rollback owner confirmed.
- [ ] No production data used in training prompts/uploads.
- [ ] Break-glass access verified.
- [ ] Audit trail retained using named accounts.
