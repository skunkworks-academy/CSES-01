# Lab 03 Template — Workload Protection Selection Matrix

Use this template to select the most appropriate Defender workload protection plan for each workload in scope.

| Workload | Risk signal | Recommended Defender plan | Evidence to collect | Priority |
|---|---|---|---|---|
| Storage account | Public access, malware upload risk, sensitive data exposure | Defender for Storage | Storage configuration and plan status | High if internet-facing or sensitive data |
| AKS / Kubernetes | Vulnerable image, exposed API, weak cluster posture | Defender for Containers | AKS posture, image scan, Kubernetes recommendations | High if production or internet-exposed |
| App Service | Runtime threat, exposed app endpoint, insecure configuration | Defender for App Service | App Service recommendations and alerts | Medium/High depending business criticality |
| Azure AI / Foundry | Prompt injection, data leakage, unsafe behavior, weak identity boundary | Defender for AI Services / AI workload protection | AI plan status, AI security dashboard, alerts | High if AI handles business/customer data |
| VM / Server | Missing EDR, vulnerabilities, exposed management ports | Defender for Servers | Server recommendations and endpoint status | High for internet-facing or privileged systems |

## Selection rationale

| Selected workload | Why selected | Expected learning outcome | Cost / risk consideration |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |
