# Lab 05 Template — Attack Path and Remediation Planning

**Student name:**  
**Environment:** Sandbox / customer live / demo  
**Attack path source:** Defender for Cloud / Security Exposure Management / instructor scenario  

## 1. Attack path summary

| Field | Response |
|---|---|
| Attack path ID / label |  |
| Entry point |  |
| Intermediate asset(s) |  |
| Critical asset at risk |  |
| Risk level |  |
| Business impact |  |

## 2. Path decomposition

| Step | Asset / identity | Weakness | Evidence | Remediation action |
|---:|---|---|---|---|
| 1 |  |  |  |  |
| 2 |  |  |  |  |
| 3 |  |  |  |  |
| 4 |  |  |  |  |

## 3. Choke points

Identify points where one remediation would break or reduce the path.

| Choke point | Why it matters | Control owner | Fix complexity | Priority |
|---|---|---|---|---|
|  |  |  |  |  |

## 4. Remediation plan

| Action | Control family | Owner | Risk reduction | Due date | Validation method |
|---|---|---|---|---|---|
| Remove excessive role assignment | Identity / RBAC |  |  |  |  |
| Restrict public exposure | Network / workload |  |  |  |  |
| Enable Defender plan | Workload protection |  |  |  |  |
| Add governance rule | Posture management |  |  |  |  |

## 5. Executive summary

Write a 5–7 sentence summary suitable for a customer stakeholder.
