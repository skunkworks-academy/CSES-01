# Executive Summary Template — CESE323 Security Review

## Situation

Summarize the current cloud security posture in business language.

## Key risks

| Risk | Business impact | Priority |
|---|---|---|
|  |  |  |

## Recommended actions

| Action | Expected outcome | Target timeframe |
|---|---|---|
|  |  |  |

## Decisions required

| Decision | Decision owner | Deadline |
|---|---|---|
|  |  |  |

## Final recommendation

Provide a concise recommendation for the next 30 days.
