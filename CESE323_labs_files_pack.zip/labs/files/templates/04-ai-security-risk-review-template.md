# Lab 04 Template — AI Security Risk Review

**AI workload/resource:**  
**Resource group/subscription:**  
**Model/service type:** Azure AI service / Azure OpenAI / Microsoft Foundry / Other  
**Data sensitivity:** Public / Internal / Confidential / Restricted  

## 1. AI workload inventory

| Component | Name | Purpose | Identity used | Data handled | Notes |
|---|---|---|---|---|---|
| AI service / Foundry project |  |  |  |  |  |
| Model deployment / endpoint |  |  |  |  |  |
| Storage / data source |  |  |  |  |  |
| App / API consumer |  |  |  |  |  |

## 2. AI risk assessment

| Risk | Scenario | Existing control | Gap | Severity | Finding ID |
|---|---|---|---|---|---|
| Prompt injection | User manipulates model instructions |  |  |  |  |
| Sensitive data leakage | Prompt/response exposes confidential data |  |  |  |  |
| Overprivileged workload identity | Managed identity has broad access |  |  |  |  |
| Unsafe model behavior | Output violates policy or safety rule |  |  |  |  |
| Missing monitoring | Alerts not visible in Defender/SecOps |  |  |  |  |

## 3. Defender for AI Services review

| Check | Expected evidence | Status | Notes |
|---|---|---|---|
| Defender for Cloud enabled on subscription | Environment settings |  |  |
| AI Services plan enabled where required | Defender plans page |  |  |
| AI security posture dashboard reviewed | Data and AI security dashboard |  |  |
| Alerts/incidents reviewed | Defender portal / Defender XDR |  |  |
| Purview requirement checked | Only if using DSPM/data security for AI |  |  |

## 4. Recommended controls

| Control | Owner | Implementation path | Target date |
|---|---|---|---|
| Least privilege for AI identities |  |  |  |
| No sensitive data in prompts |  |  |  |
| Enable AI threat protection |  |  |  |
| Add logging/monitoring |  |  |  |
| Define AI usage policy |  |  |  |
