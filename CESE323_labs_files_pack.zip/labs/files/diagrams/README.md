# Diagram Assets

The `.mmd` files in this folder are Mermaid diagrams. They can be rendered by Docusaurus, GitHub markdown previews with Mermaid enabled, VS Code Mermaid extensions, or converted into SVG/PNG during publishing.

## Files

| File | Purpose |
|---|---|
| `defender-cloud-lab-flow.mmd` | Overall course lab workflow |
| `cspm-posture-review-flow.mmd` | Defender for Cloud posture review sequence |
| `workload-protection-selection-map.mmd` | Defender workload protection decision path |
| `ai-security-risk-flow.mmd` | AI workload risk-review workflow |
| `attack-path-remediation-flow.mmd` | Attack path decomposition and remediation workflow |

## Publishing recommendation

For GitHub Pages/Docusaurus, keep Mermaid source files under version control and render diagrams at build time. For static LMS uploads, export the diagrams to SVG or PNG and reference the exported versions in the student lab guide.
