# Screenshot Placeholder — Recommendations

Replace this placeholder with a current screenshot captured from the approved lab tenant.

## Validation fields

| Field | Value |
|---|---|
| Screenshot ID |  |
| Captured by |  |
| Capture date |  |
| Portal |  |
| Navigation path |  |
| Lab ID |  |
| Redaction completed |  |
| Validated against current portal |  |
| Approved for student material |  |

## Notes

Do not publish screenshots containing production data, real user identities, subscription IDs, secrets, access tokens, or customer confidential content.
