# Screenshot Capture Guide

This folder intentionally contains screenshot placeholders and validation metadata rather than tenant-specific portal screenshots.

## Why placeholders are used

Microsoft portals change frequently and tenant data can be sensitive. Capture screenshots from the current lab tenant only after confirming:

- The environment is a sandbox or approved customer live environment.
- No confidential data, user PII, subscription IDs, secrets, tokens, or production identifiers are visible.
- The screenshot matches the current Microsoft portal UI.
- The screenshot has been reviewed against `validation/screenshot-validation-register.csv`.

## Naming convention

Use this convention:

```text
<lab-id>_<portal-area>_<screen-purpose>_<yyyymmdd>.png
```

Examples:

```text
lab02_defender-cloud_secure-score_20260525.png
lab02_defender-cloud_recommendations_20260525.png
lab03_defender-cloud_environment-settings_20260525.png
lab04_defender-cloud_ai-services-plan_20260525.png
lab05_defender-cloud_attack-path_20260525.png
```

## Required screenshot set

| Screenshot ID | Portal area | Purpose |
|---|---|---|
| SS-001 | Azure portal > Microsoft Defender for Cloud | Defender for Cloud landing / overview |
| SS-002 | Defender for Cloud > Environment settings | Confirm subscription and Defender plan settings |
| SS-003 | Defender for Cloud > Recommendations | Review top recommendations |
| SS-004 | Defender for Cloud > Secure Score | Review posture score and control groups |
| SS-005 | Defender for Cloud > Regulatory compliance | Review control gaps |
| SS-006 | Defender for Cloud > Workload protections / Defender plans | Confirm selected plan coverage |
| SS-007 | Defender for Cloud / Microsoft Defender portal | Review alert or incident example |
| SS-008 | Defender for Cloud > Attack paths / exposure views | Review attack path or exposure chain |
| SS-009 | Defender for Cloud > Data and AI security dashboard | Review AI security posture where available |
| SS-010 | Microsoft Entra admin center | Review identity/RBAC context where included |

## Redaction checklist

- [ ] Tenant name safe to show.
- [ ] Subscription ID hidden or intentionally shown for internal-only material.
- [ ] User names/emails hidden unless demo users.
- [ ] No real customer data.
- [ ] No secrets, keys, SAS tokens, API keys, connection strings, access tokens, or private URLs.
- [ ] Screenshot matches current portal navigation.
